var url = 'wss://YOUR WEBSOCKET URL HERE eg. 0123456789.execute-api.us-west-2.amazonaws.com/staging/';

function connect(url) {
  var ws = new WebSocket(url);
  ws.onopen = function(event) {
    // subscribe to some channels
    /*ws.send(JSON.stringify({
        //.... some message the I must send when I connect ....
    }));*/
    console.log("socket open")
    console.log(event)
  };

  ws.onmessage = function(event) {
    console.log('Message:', event.data);
    console.log('Additional message from server', event)
    sampleJSONpayload();
    document.getElementById("loaderDiv").classList.add("hideLoader");
  };

  ws.onclose = function(event) {
    console.log('Socket is closed. Reconnect will be attempted in 5 second.', event.reason);
    setTimeout(function() {
      connect(url);
    }, 5000);
  };

  ws.onerror = function(error) {
    console.error('Socket encountered error: ', error.message, 'Closing socket');
    ws.close();
  };

/*BUTTON CLICK EVENTS*/
document.getElementById("submitbtn").addEventListener("click", function () {
  var form = document.getElementById("coordinatesform");
  //form.submit();
  var json = parseFormToJSON(form);
  console.log("sending data")
  document.getElementById("loaderDiv").classList.remove("hideLoader");
  

  if (ws.readyState !== WebSocket.CLOSED) {
   console.log("Socket Open; Ok to send message")
   ws.send(json);
  }
  else{
    console.log("Socket Closed; Attempting to reopen socket to send message")
    ws.send(json); 
  }   
  
});

document.getElementById("clearbtn").addEventListener("click", function () {
  //form.submit();
  console.log("clearning form")
  document.getElementById("coordinatesform").reset();
});

document.getElementById("querybtn").addEventListener("click", function () {
  //form.submit();
  console.log("query data from socket endpoint")
  document.getElementById("coordinatesform").reset();
});

document.getElementById("loader").addEventListener("click", function () {
  document.getElementById("loaderDiv").classList.add("hideLoader");
});

}
connect(url);

function parseFormToJSON(form){
  console.log("converting form data to json")
  const data = new FormData(form);
  console.log(data)
  var object = {};
  data.forEach(function(value, key){
      object[key] = value;
  });
  var json = JSON.stringify(object);
  console.log("json_payload")
  console.log(json)
  return json;    
}

function sampleJSONpayload(){

var samplejson= {
    data:[
        {datetime:"1234", s3link: "s3.blahblah"},
        {datetime:"5678", s3link: "s3.blahblah"}
    ]
}

samplejson= [
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/6/3/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "13070649"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/3/10/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "12034240"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/T/FK/2020/4/14/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "11977149"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/6/3/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "13070649"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/3/10/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "12034240"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/T/FK/2020/4/14/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "11977149"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/6/3/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "13070649"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/3/10/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "12034240"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/T/FK/2020/4/14/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "11977149"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/6/3/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "13070649"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/3/10/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "12034240"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/T/FK/2020/4/14/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "11977149"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/6/3/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "13070649"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/3/10/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "12034240"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/T/FK/2020/4/14/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "11977149"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/6/3/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "13070649"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/3/10/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "12034240"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/T/FK/2020/4/14/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "11977149"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/6/3/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "13070649"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/3/10/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "12034240"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/T/FK/2020/4/14/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "11977149"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/6/3/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "13070649"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/S/FJ/2020/3/10/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "12034240"
    },
    {
        "url" : "https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/T/FK/2020/4/14/0/preview.jpg",
        "date" : "Jun 03 2020 12:03:43",
        "titleId" : "11977149"
    }
]
//console.log("sample json: \n" + JSON.stringify(samplejson))

parseJSONpayload(samplejson);

}

function parseJSONpayload(jsonPayload={}){
    if(jsonPayload.length==0){
        console.log("Expecting jsonPayload to be a JSON array")
    }
    else{

        /* clear existing elements */
        var slideshowNode = document.getElementById("slideshow-container");
        var dotsNode = document.getElementById("slideshow-dots");
        slideshowNode.innerHTML = '';
        dotsNode.innerHTML = '';
        /* iterate through json array */
        for (var i = 0; i < jsonPayload.length; i++){
          console.log("array index: " + i);
          var obj = jsonPayload[i];
          
          jsonUIbuilder(obj);

          /*for (var key in obj){
            var value = obj[key];
            console.log(key + ": " + value);
          }*/
          //console.log(obj.date);
        }
    }

}


function jsonUIbuilder(jsonPayload={}){

var div = document.createElement("div");
div.setAttribute('class', 'mySlides fade');

var img = document.createElement("img");
img.setAttribute('class', 'imgDisplay');
img.src = jsonPayload.url;
div.appendChild(img);

var textDiv = document.createElement("div");
textDiv.setAttribute('class', 'text');
textDiv.innerHTML = jsonPayload.date
div.appendChild(textDiv);

var textDiv = document.createElement("div");
textDiv.setAttribute('class', 'text');
textDiv.innerHTML = jsonPayload.titleId
div.appendChild(textDiv);

document.getElementById("slideshow-container").appendChild(div);

/*dots*/
var span = document.createElement("span")
span.setAttribute('class', "dot");
document.getElementById("slideshow-dots").appendChild(span);

}








function defaultIMGui(jsonPayload={}){

var div = document.createElement("div");
div.setAttribute('class', 'mySlides fade');

var img = document.createElement("img");
img.setAttribute('class', 'imgDisplay');
img.src = './img_snow_wide.jpg';
//img.src ='https://roda.sentinel-hub.com/sentinel-s2-l1c/tiles/10/T/FK/2020/4/14/0/preview.jpg'

var textDiv = document.createElement("div");
textDiv.setAttribute('class', 'text');
textDiv.innerHTML="Caption Text 4"

div.appendChild(img);
div.appendChild(textDiv);

document.getElementById("slideshow-container").appendChild(div);

/*dots*/
var span = document.createElement("span")
span.setAttribute('class', "dot");
document.getElementById("slideshow-dots").appendChild(span);

}
